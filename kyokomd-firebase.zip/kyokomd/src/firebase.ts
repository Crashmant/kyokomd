import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: "AIzaSyB5u-ZTYxkfPV4HibuvavhaePace0X5agI",
  authDomain: "kyokomd-41a97.firebaseapp.com",
  projectId: "kyokomd-41a97",
  storageBucket: "kyokomd-41a97.firebasestorage.app",
  messagingSenderId: "514877865535",
  appId: "1:514877865535:web:fc7fabfe5c5c507c6a828a"
}

const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)
