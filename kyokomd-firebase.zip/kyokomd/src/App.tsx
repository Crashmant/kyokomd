import React, { useEffect, useMemo, useState } from 'react'
import { db } from './firebase'
import { collection, doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore'

function App() {
  const groupCategories = useMemo(
    () => ['Anime', 'Game', 'Bot WhatsApp', 'Jual Beli', 'Cari Teman', 'Teknologi', 'Musik', 'Belajar', 'Daerah', 'Random'],
    [],
  )
  const gameData = useMemo(
    () => ({
      RPG: [
        { name: 'Genshin Impact', link: 'https://play.google.com/store/apps/details?id=com.miHoYo.GenshinImpact' },
        { name: 'Wuthering Waves', link: 'https://play.google.com/store/apps/details?id=com.kurogame.wutheringwaves.global' },
        { name: 'Neverness To Everness', link: 'https://play.google.com/store/apps/details?id=com.hottagames.nte' },
      ],
      MOBA: [
        { name: 'Honor of Kings', link: 'https://play.google.com/store/apps/details?id=com.levelinfinite.sgameGlobal' },
        { name: 'Mobile Legends', link: 'https://play.google.com/store/apps/details?id=com.mobile.legends' },
      ],
      FPS: [
        { name: 'Delta Force', link: 'https://play.google.com/store/apps/details?id=com.garena.game.df' },
        { name: 'Free Fire', link: 'https://play.google.com/store/apps/details?id=com.dts.freefireth' },
        { name: 'Blood Strike', link: 'https://play.google.com/store/apps/details?id=com.netease.newspike' },
      ],
    }),
    [],
  )

  // ── Splash screen ─────────────────────────────────────────────────────────
  const [splashDone, setSplashDone] = useState(false)
  const [splashFade, setSplashFade] = useState(false)

  // ── Rating ─────────────────────────────────────────────────────────────────
  const [ratings, setRatings] = useState<{id:string;name:string;star:number;comment:string;createdAt:number;fake?:boolean}[]>([])
  const [ratingForm, setRatingForm] = useState({ name: '', star: 0, comment: '' })
  const [ratingHover, setRatingHover] = useState(0)
  const [ratingStatus, setRatingStatus] = useState<'idle'|'success'|'error'>('idle')
  const [ratingFilter, setRatingFilter] = useState<number | null>(null)
  const [ratingBubbleOpen, setRatingBubbleOpen] = useState(false)

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [groups, setGroups] = useState<Record<string, { name: string; link: string; desc: string; createdAt: number }[]>>({})
  const [groupForm, setGroupForm] = useState({ name: '', link: '', category: groupCategories[0], desc: '' })
  const [groupErrors, setGroupErrors] = useState({ link: '' })
  const [activeGroupIndex, setActiveGroupIndex] = useState(0)
  const [groupSlideDirection, setGroupSlideDirection] = useState<'left' | 'right'>('right')
  const [groupSearch, setGroupSearch] = useState('')
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({})
  const [activeGenre, setActiveGenre] = useState<'RPG' | 'MOBA' | 'FPS'>('RPG')
  const [feedback, setFeedback] = useState({ name: '', category: 'Saran', message: '' })
  const [feedbackStatus, setFeedbackStatus] = useState<{ type: 'idle' | 'success' | 'error'; message: string }>({
    type: 'idle',
    message: '',
  })
  const [chatOpen, setChatOpen] = useState(false)
  const [chatInput, setChatInput] = useState('')
  const [chatLoading, setChatLoading] = useState(false)
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
    {
      role: 'assistant',
      content: 'Halo! Aku KyokoAI. Tanyakan apa saja tentang KyokoMd atau komunitasnya.',
    },
  ])
  const [chatMemory, setChatMemory] = useState({
    userName: '',
    lastTopic: 'KyokoMd',
    lastMood: 'calm' as 'happy' | 'calm' | 'shy' | 'annoyed' | 'excited',
    lastUserMessage: '',
  })
  const [lastFallbackIndex, setLastFallbackIndex] = useState(0)
  const [menuOpen, setMenuOpen] = useState(false)
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')
  const [showScrollTop, setShowScrollTop] = useState(false)
  const [visitorCount, setVisitorCount] = useState(0)
  const [newsFilter, setNewsFilter] = useState('Semua')

  // APK MOD ADMIN
  const ADMIN_USER = 'KyokoRyu'
  const ADMIN_CODE = '20062005'
  const [isAdmin, setIsAdmin] = useState(() => sessionStorage.getItem('isAdmin') === 'true')
  const [adminModalOpen, setAdminModalOpen] = useState(false)
  const [adminUser, setAdminUser] = useState('')
  const [adminCode, setAdminCode] = useState('')
  const [adminError, setAdminError] = useState('')
  const [apkTab, setApkTab] = useState<'apk' | 'free' | 'premium'>('apk')
  const [uploadModal, setUploadModal] = useState<'apk' | 'free' | 'premium' | null>(null)
  const [uploadForm, setUploadForm] = useState({ name: '', link: '', version: '', desc: '', waLink: '', category: 'Lainnya' })
  const [apkList, setApkList] = useState<{id:string;name:string;link:string;version:string;desc:string}[]>([])
  const [scbotFreeList, setScbotFreeList] = useState<{id:string;name:string;link:string;version:string;desc:string}[]>([])
  const [scbotPremiumList, setScbotPremiumList] = useState<{id:string;name:string;price:string;version:string;desc:string;waLink:string}[]>([])
  const [menuDots, setMenuDots] = useState<string | null>(null)
  // APK category filter & search
  const apkCategories = ['Game', 'Sosmed', 'AI', 'Lainnya']
  const scCategories = ['Semua', 'Game', 'Utility', 'Fun', 'Lainnya']
  const [apkCategory, setApkCategory] = useState<string>('Semua')
  const [apkSearchOpen, setApkSearchOpen] = useState(false)
  const [apkSearch, setApkSearch] = useState('')
  const [freeCategory, setFreeCategory] = useState<string>('Semua')
  const [freeSearchOpen, setFreeSearchOpen] = useState(false)
  const [freeSearch, setFreeSearch] = useState('')
  const [premiumCategory, setPremiumCategory] = useState<string>('Semua')
  const [premiumSearchOpen, setPremiumSearchOpen] = useState(false)
  const [premiumSearch, setPremiumSearch] = useState('')
  // Rating show more
  const [ratingShowCount, setRatingShowCount] = useState(3)
  const [musicPlaying, setMusicPlaying] = useState(false)
  const audioRef = React.useRef<HTMLAudioElement | null>(null)

  React.useEffect(() => {
    const audio = new Audio('https://c.termai.cc/a138/nOnf2vY.mp3')
    audio.loop = true
    audio.volume = 0.4
    audioRef.current = audio
    return () => { audio.pause(); audio.src = '' }
  }, [])

  const toggleMusic = () => {
    const audio = audioRef.current
    if (!audio) return
    if (musicPlaying) {
      audio.pause()
      setMusicPlaying(false)
    } else {
      audio.play().then(() => setMusicPlaying(true)).catch(() => {})
    }
  }
  // EDIT BERITA DI SINI - tambah objek baru untuk berita terbaru
  const gameNews = useMemo(
    () => [
      {
        game: 'genshin',
        title: 'Genshin Impact Version 5.5 Brings New Characters',
        description: 'Update terbaru Genshin Impact menghadirkan karakter baru dan area eksplorasi yang lebih luas.',
        url: 'https://genshin.hoyoverse.com',
        image: 'https://c.termai.cc/a168/fWL8x6q.jpg',
        date: '2026-05-09',
        source: 'HoYoverse Official',
      },
      {
        game: 'mobile-legends',
        title: 'Mobile Legends Season Update: Meta Baru dan Balance Patch',
        description: 'Patch terbaru Mobile Legends membawa perubahan meta dan penyesuaian hero utama.',
        url: 'https://m.mobilelegends.com',
        image: 'https://c.termai.cc/a167/OZkTk.jpg',
        date: '2026-05-10',
        source: 'Moonton News',
      },
      {
        game: 'wuthering-waves',
        title: 'Wuthering Waves Update: Eksplorasi dan Event Musim Baru',
        description: 'Event terbaru membuka area baru dan reward eksklusif untuk pemain aktif.',
        url: 'https://wutheringwaves.kurogame.com',
        image: 'https://c.termai.cc/a109/QJM.jpg',
        date: '2026-05-11',
        source: 'Kuro Games',
      },
      {
        game: 'free-fire',
        title: 'Free Fire menghadirkan mode baru dan kolaborasi spesial',
        description: 'Mode terbatas dan bundle kolaborasi baru tersedia di update terbaru Free Fire.',
        url: 'https://ff.garena.com',
        image: 'https://c.termai.cc/a184/MPYWRSy.jpg',
        date: '2026-05-12',
        source: 'Garena',
      },
    ],
    [],
  )

  const activeCategory = groupCategories[activeGroupIndex]

  useEffect(() => {
    const elements = document.querySelectorAll('.fade-section')
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view')
          }
        })
      },
      { threshold: 0.2 },
    )

    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  // ── Splash screen timer ───────────────────────────────────────────────────
  useEffect(() => {
    const fadeTimer = setTimeout(() => setSplashFade(true), 2400)
    const doneTimer = setTimeout(() => setSplashDone(true), 3000)
    return () => { clearTimeout(fadeTimer); clearTimeout(doneTimer) }
  }, [])

  // ── Firebase: Load ratings ────────────────────────────────────────────────
  useEffect(() => {
    const fakeRatings = [
      { name: 'Arya_Gaming', star: 5, comment: 'Bot paling lengkap! Fiturnya banyak banget, admin juga ramah. Recommended banget buat yang cari bot WA berkualitas!' },
      { name: 'NadiaXplore', star: 5, comment: 'Udah lama pake KyokoMd dan ga pernah kecewa. Update terus, respon cepat.' },
      { name: 'RizkiBot27', star: 4, comment: 'Bagus banget, cuma minta tambah fitur game baru. Overall memuaskan!' },
      { name: 'Maulana_Tech', star: 5, comment: 'Top banget! Grup komunitasnya aktif, botnya stabil. 10/10 👍' },
      { name: 'SintaWijaya', star: 5, comment: 'KyokoMd emang beda dari bot lain. Premium worth it banget harganya.' },
      { name: 'FahriXD', star: 4, comment: 'Suka banget sama tampilan webnya, keren dan modern. Bot juga oke!' },
      { name: 'Putri_Gamer', star: 5, comment: 'Paling suka fitur direktori grupnya, gampang cari komunitas baru.' },
    ]
    const unsub = onSnapshot(collection(db, 'ratings'), (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as {name:string;star:number;comment:string;createdAt:number;fake?:boolean}) }))
      items.sort((a, b) => b.createdAt - a.createdAt)
      if (snap.empty) {
        fakeRatings.forEach((r, i) => {
          const id = `fake-${i}`
          setDoc(doc(db, 'ratings', id), { ...r, createdAt: Date.now() - (i * 86400000), fake: true })
        })
      }
      setRatings(items)
    })
    return () => unsub()
  }, [])

  // ── Firebase: Load & listen groups ──────────────────────────────────────────
  useEffect(() => {
    const expiryMs = 2592000000
    const initialGroups = groupCategories.reduce(
      (acc, category) => { acc[category] = []; return acc },
      {} as Record<string, { name: string; link: string; desc: string; createdAt: number }[]>,
    )

    const unsub = onSnapshot(collection(db, 'groups'), (snapshot) => {
      const loaded: Record<string, { name: string; link: string; desc: string; createdAt: number }[]> = { ...initialGroups }
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as { category: string; name: string; link: string; desc: string; createdAt: number }
        if (!data.category || !groupCategories.includes(data.category)) return
        const createdAt = typeof data.createdAt === 'number' ? data.createdAt : Date.now()
        if (Date.now() - createdAt > expiryMs) return
        if (!loaded[data.category]) loaded[data.category] = []
        loaded[data.category].push({ name: data.name, link: data.link, desc: data.desc, createdAt })
      })
      // sort each category newest first
      Object.keys(loaded).forEach((cat) => {
        loaded[cat].sort((a, b) => b.createdAt - a.createdAt)
      })
      setGroups(loaded)
    })
    return () => unsub()
  }, [groupCategories])

  // ── Firebase: Listen APK / SC lists ──────────────────────────────────────
  useEffect(() => {
    const unsubApk = onSnapshot(collection(db, 'apkList'), (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as {name:string;link:string;version:string;desc:string}) }))
      setApkList(items)
    })
    const unsubFree = onSnapshot(collection(db, 'scbotFreeList'), (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as {name:string;link:string;version:string;desc:string}) }))
      setScbotFreeList(items)
    })
    const unsubPremium = onSnapshot(collection(db, 'scbotPremiumList'), (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as {name:string;price:string;version:string;desc:string;waLink:string}) }))
      setScbotPremiumList(items)
    })
    return () => { unsubApk(); unsubFree(); unsubPremium() }
  }, [])

  useEffect(() => {
    const storedTheme = localStorage.getItem('theme')
    if (storedTheme === 'light') {
      setTheme('light')
      document.body.classList.add('theme-light')
    }
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    // Increment visitor di Firestore dan animate count
    let rafId = 0
    const visitorDocRef = doc(db, 'stats', 'visitors')
    const runAnimation = (target: number, from: number) => {
      const start = performance.now()
      const duration = 1800
      const animate = (time: number) => {
        const progress = Math.min((time - start) / duration, 1)
        const ease = 1 - Math.pow(1 - progress, 3)
        setVisitorCount(Math.floor(from + ease * (target - from)))
        if (progress < 1) rafId = requestAnimationFrame(animate)
      }
      rafId = requestAnimationFrame(animate)
    }
    // Increment count
    import('firebase/firestore').then(({ increment, updateDoc, getDoc, setDoc }) => {
      getDoc(visitorDocRef).then(snap => {
        if (!snap.exists()) {
          setDoc(visitorDocRef, { count: 1280 }).then(() => {
            runAnimation(1280, 0)
          })
        } else {
          const current = snap.data().count || 1280
          updateDoc(visitorDocRef, { count: increment(1) }).catch(() => {})
          runAnimation(current + 1, Math.max(0, current - 5))
        }
      }).catch(() => {
        runAnimation(1280, 1270)
      })
    })
    return () => cancelAnimationFrame(rafId)
  }, [])


  const handleGroupSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!groupForm.name || !groupForm.link || !groupForm.desc) {
      return
    }
    const normalizedLink = groupForm.link.trim()
    const normalizedLower = normalizedLink.toLowerCase()
    const isWhatsAppLink =
      normalizedLower.includes('chat.whatsapp.com') || normalizedLower.includes('whatsapp.com/channel')
    if (!isWhatsAppLink) {
      setGroupErrors({ link: 'Masukkan link WhatsApp yang valid!' })
      return
    }
    const existingLinks = Object.values(groups)
      .flat()
      .map((group) => group.link.trim().toLowerCase())
    if (existingLinks.includes(normalizedLower)) {
      setGroupErrors({ link: 'Link grup ini sudah terdaftar!' })
      return
    }
    setGroupErrors({ link: '' })
    const newGroup = { category: groupForm.category, name: groupForm.name, link: normalizedLink, desc: groupForm.desc, createdAt: Date.now() }
    const docId = `${groupForm.category}-${Date.now()}`
    setDoc(doc(db, 'groups', docId), newGroup).catch(console.error)
    setGroupForm({ name: '', link: '', category: groupCategories[0], desc: '' })
    setIsModalOpen(false)
  }

  const handleGroupNav = (direction: 'left' | 'right') => {
    setGroupSlideDirection(direction)
    setActiveGroupIndex((prev) => {
      if (direction === 'left') {
        return prev === 0 ? groupCategories.length - 1 : prev - 1
      }
      return prev === groupCategories.length - 1 ? 0 : prev + 1
    })
  }

  const filteredGroups = useMemo(() => {
    const query = groupSearch.trim().toLowerCase()
    if (!query) return [] as { category: string; name: string; link: string; desc: string; createdAt: number }[]
    return groupCategories.flatMap((category) =>
      (groups[category] || [])
        .filter((group) => [group.name, group.desc, category].some((field) => field.toLowerCase().includes(query)))
        .map((group) => ({ ...group, category })),
    )
  }, [groupCategories, groupSearch, groups])

  const expiryMs = 2592000000
  const getDaysLeft = (createdAt: number) => Math.max(0, Math.ceil((createdAt + expiryMs - Date.now()) / 86400000))

  const handleRenewGroup = (link: string) => {
    const normalized = link.trim().toLowerCase()
    setGroups((prev) => {
      const updated = { ...prev }
      Object.keys(updated).forEach((category) => {
        updated[category] = updated[category].map((group) =>
          group.link.trim().toLowerCase() === normalized ? { ...group, createdAt: Date.now() } : group,
        )
      })
      return updated
    })
    window.alert('Grup berhasil diperbarui! Aktif 30 hari lagi.')
  }

  const visibleGroups = useMemo(() => {
    const items = groups[activeCategory] || []
    if (expandedCategories[activeCategory]) return items
    return items.slice(0, 5)
  }, [activeCategory, expandedCategories, groups])

  const handleFeedbackSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setFeedbackStatus({ type: 'idle', message: '' })
    try {
      const formData = new FormData()
      formData.append('nama', feedback.name)
      formData.append('kategori', feedback.category)
      formData.append('pesan', feedback.message)
      formData.append('_subject', 'Masukan KyokoMd')
      formData.append('_captcha', 'false')

      const response = await fetch('https://formsubmit.co/kyokomd2006@gmail.com', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
        },
        body: formData,
      })

      if (!response.ok) {
        throw new Error('Gagal mengirim')
      }

      setFeedbackStatus({ type: 'success', message: 'Masukan berhasil dikirim! Terima kasih.' })
      setFeedback({ name: '', category: 'Saran', message: '' })
    } catch (error) {
      setFeedbackStatus({ type: 'error', message: 'Gagal mengirim. Coba lagi nanti.' })
    }
  }

  const handleRatingSubmit = async () => {
    if (!ratingForm.name.trim() || ratingForm.star === 0) return
    const id = `rating-${Date.now()}`
    await setDoc(doc(db, 'ratings', id), {
      name: ratingForm.name.trim(),
      star: ratingForm.star,
      comment: ratingForm.comment.trim(),
      createdAt: Date.now(),
      fake: false,
    }).catch(console.error)
    setRatingForm({ name: '', star: 0, comment: '' })
    setRatingHover(0)
    setRatingStatus('success')
    setTimeout(() => setRatingStatus('idle'), 3000)
  }

  const handleDeleteRating = (id: string) => {
    if (!window.confirm('Hapus rating ini?')) return
    deleteDoc(doc(db, 'ratings', id)).catch(console.error)
  }

  const handleChatSend = async () => {
    if (!chatInput.trim() || chatLoading) return
    const input = chatInput.trim()
    setChatInput('')
    setChatMessages((prev) => [...prev, { role: 'user', content: input }])
    setChatLoading(true)

    const nameMatch = input.match(/\b(?:nama(?:ku| saya)?|aku|saya)\s*(?:adalah|=)\s*([A-Za-z0-9_\-\s]{2,24})/i)
    const inferredName = nameMatch ? nameMatch[1].trim() : chatMemory.userName
    const inferredMood = (() => {
      if (/[!]{2,}|\b(seru|mantap|keren|yay|yey|asik)\b/i.test(input)) return 'excited'
      if (/\b(hehe|hihi|malu|gugup)\b/i.test(input)) return 'shy'
      if (/\b(capek|sepi|bingung|ragu)\b/i.test(input)) return 'calm'
      if (/\b(kesel|sebel|males|kesal)\b/i.test(input)) return 'annoyed'
      if (/\b(senang|bahagia|makasih|terima kasih)\b/i.test(input)) return 'happy'
      return chatMemory.lastMood
    })()
    const inferredTopic = (() => {
      if (/\b(grup|group|komunitas|link)\b/i.test(input)) return 'Komunitas'
      if (/\b(bot|fitur|plugin|command)\b/i.test(input)) return 'Fitur Bot'
      if (/\bgame|genshin|moba|fps|rpg\b/i.test(input)) return 'Game'
      return chatMemory.lastTopic
    })()

    setChatMemory((prev) => ({
      ...prev,
      userName: inferredName,
      lastMood: inferredMood,
      lastTopic: inferredTopic,
      lastUserMessage: input,
    }))

    const fallbackVariants = [
      'Hmm... aku agak blank sebentar. Coba ulangi dengan kalimat yang lebih singkat ya?',
      'Wah, sinyalku lagi goyah. Boleh tanya lagi? Aku bakal jawab sebaik mungkin.',
      'Maaf, kepalaku lagi penuh. Coba tanya lagi ya~',
      'Sebentar ya, aku lagi mikir. Ulang pertanyaannya, aku jawab kok.',
      'Aku masih di sini kok. Coba tanya lagi pelan-pelan, ya?',
    ]
    const nextFallback = (offset = 0) => {
      const index = (lastFallbackIndex + 1 + offset) % fallbackVariants.length
      setLastFallbackIndex(index)
      return fallbackVariants[index]
    }

    try {
      const pesanDikirim = `Kamu adalah KyokoAI, asisten virtual KyokoMd. Jawab SINGKAT dan PADAT maksimal 3-4 kalimat saja, jangan panjang. Hanya jawab seputar: KyokoMd bot WhatsApp, cara gabung grup, fitur bot, rekomendasi game (Genshin Impact, Wuthering Waves, Neverness to Everness, Honor of Kings, Mobile Legends, Delta Force, Free Fire, Blood Strike), info top-up di saweria.co/YukiDesu/toko-top-up, dan direktori grup. Jika di luar topik jawab: "Maaf, aku hanya bisa membantu seputar KyokoMd dan fitur yang tersedia di web ini." Pertanyaan user: ${input}`
      const response = await fetch(`https://api-faa.my.id/faa/claude-ai?text=${encodeURIComponent(pesanDikirim)}`)
      if (!response.ok) {
        throw new Error('Request gagal')
      }
      const data = await response.json()
      if (data?.status === false) {
        throw new Error(data?.error || 'Request gagal')
      }
      const rawReply = typeof data?.result === 'string' ? data.result : nextFallback(1)
      const cleaned = rawReply
        .replace(/\n\n+/g, '\n')
        .replace(/[\*_`>#\-]/g, '')
        .replace(/\s{2,}/g, ' ')
        .trim()
      const sentences = cleaned.split(/(?<=[.!?])\s+/).filter(Boolean)
      const limited = sentences.length > 4 ? `${sentences.slice(0, 4).join(' ')}...` : cleaned
      const reply = limited.replace(/\n/g, ' ').trim()
      setChatMessages((prev) => [...prev, { role: 'assistant', content: reply || nextFallback(1) }])
    } catch (error) {
      setChatMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Maaf, AI sedang tidak tersedia. Coba lagi nanti.' },
      ])
    } finally {
      setChatLoading(false)
    }
  }

  const handleThemeToggle = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark'
    setTheme(nextTheme)
    document.body.classList.toggle('theme-light', nextTheme === 'light')
    localStorage.setItem('theme', nextTheme)
  }

  const handleMenuClick = (targetId: string) => {
    const element = document.getElementById(targetId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
    setMenuOpen(false)
  }


  const handleAdminLogin = () => {
    if (adminUser === ADMIN_USER && adminCode === ADMIN_CODE) {
      sessionStorage.setItem('isAdmin', 'true')
      setIsAdmin(true)
      setAdminModalOpen(false)
      setAdminError('')
      setAdminUser('')
      setAdminCode('')
    } else {
      setAdminError('Username atau kode salah!')
    }
  }

  const handleAdminLogout = () => {
    sessionStorage.removeItem('isAdmin')
    setIsAdmin(false)
  }

  const handleUpload = () => {
    if (!uploadForm.name || !uploadForm.link) return
    const id = `item-${Date.now()}`
    if (uploadModal === 'apk') {
      setDoc(doc(db, 'apkList', id), { name: uploadForm.name, link: uploadForm.link, version: uploadForm.version, desc: uploadForm.desc, category: uploadForm.category }).catch(console.error)
    } else if (uploadModal === 'free') {
      setDoc(doc(db, 'scbotFreeList', id), { name: uploadForm.name, link: uploadForm.link, version: uploadForm.version, desc: uploadForm.desc, category: uploadForm.category }).catch(console.error)
    } else if (uploadModal === 'premium') {
      setDoc(doc(db, 'scbotPremiumList', id), { name: uploadForm.name, price: uploadForm.link, version: uploadForm.version, desc: uploadForm.desc, waLink: uploadForm.waLink, category: uploadForm.category }).catch(console.error)
    }
    setUploadModal(null)
    setUploadForm({ name: '', link: '', version: '', desc: '', waLink: '', category: 'Lainnya' })
  }

  const handleDelete = (type: 'apk' | 'free' | 'premium', index: number) => {
    if (!window.confirm('Hapus item ini?')) return
    if (type === 'apk') {
      const item = apkList[index]
      if (item?.id) deleteDoc(doc(db, 'apkList', item.id)).catch(console.error)
    } else if (type === 'free') {
      const item = scbotFreeList[index]
      if (item?.id) deleteDoc(doc(db, 'scbotFreeList', item.id)).catch(console.error)
    } else {
      const item = scbotPremiumList[index]
      if (item?.id) deleteDoc(doc(db, 'scbotPremiumList', item.id)).catch(console.error)
    }
    setMenuDots(null)
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    if (Number.isNaN(date.getTime())) return ''
    return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
  }

  const filteredNews = useMemo(() => {
    if (newsFilter === 'Semua') return gameNews
    const map: Record<string, string> = {
      Genshin: 'genshin',
      'Mobile Legends': 'mobile-legends',
      'Free Fire': 'free-fire',
      'Wuthering Waves': 'wuthering-waves',
    }
    const target = map[newsFilter]
    return gameNews.filter((item) => item.game === target)
  }, [gameNews, newsFilter])

  const gameEmoji: Record<string, string> = {
    genshin: '✨',
    'mobile-legends': '⚔️',
    'free-fire': '🔥',
    'wuthering-waves': '🌊',
    default: '🎮',
  }

  return (
    <>
      {/* ── Splash Screen ─────────────────────────────────────────────────── */}
      {!splashDone && (
        <div className={`splash-screen ${splashFade ? 'splash-fade-out' : ''}`}>
          <div className="splash-bg-particles">
            {[...Array(18)].map((_, i) => <div key={i} className={`splash-particle p${i}`} />)}
          </div>
          <div className="splash-content">
            <div className="splash-logo-wrap">
              <div className="splash-ring splash-ring-1" />
              <div className="splash-ring splash-ring-2" />
              <div className="splash-ring splash-ring-3" />
              <img src="https://c.termai.cc/a171/MytCq.jpg" alt="KyokoMd" className="splash-logo-img" />
            </div>
            <div className="splash-brand">KYOKOMD</div>
            <div className="splash-tagline">WHATSAPP BOT · OFFICIAL</div>
            <div className="splash-loader">
              <div className="splash-loader-bar" />
            </div>
          </div>
        </div>
      )}
    <div className="page">
      <div className="noise-overlay" aria-hidden="true" />
      <header className="navbar">
        <div className="logo">
          <div className={`logo-k-wrap ${musicPlaying ? 'music-pulse' : ''}`} onClick={() => setMenuOpen(true)} role="button" aria-label="Buka menu">
            <svg className="logo-k-svg" viewBox="0 0 44 44" fill="none">
              <polygon points="22,2 40,11 40,33 22,42 4,33 4,11" fill="#c8f500" />
              <text x="22" y="30" textAnchor="middle" fontFamily="Bebas Neue, sans-serif" fontSize="22" fill="#0a0a0a" fontWeight="900">K</text>
            </svg>
            {musicPlaying && <div className="music-rings" aria-hidden="true"><span/><span/><span/></div>}
          </div>
          <div>
            <div className="logo-title">KyokoMd</div>
            <div className="logo-sub">WhatsApp Bot · Official</div>
          </div>
        </div>
        <div className="nav-actions">
          <div className="nav-icon-group">
            <a className="nav-icon-btn" href="https://saweria.co/YukiDesu/toko-top-up" target="_blank" rel="noreferrer" data-tooltip="Top-Up Shop">🛒</a>
            <button className="nav-icon-btn" type="button" onClick={() => { const el = document.getElementById('apk-mod'); el?.scrollIntoView({ behavior: 'smooth' }) }} data-tooltip="APK Mod">
              <svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18"><path d="M10 2a1 1 0 0 1 .894.553l6 12A1 1 0 0 1 16 16H4a1 1 0 0 1-.894-1.447l6-12A1 1 0 0 1 10 2Zm0 3.236L5.618 14h8.764L10 5.236ZM9 11V8h2v3H9Zm0 2h2v2H9v-2Z"/></svg>
            </button>
            <button
              className="nav-icon-btn"
              type="button"
              onClick={() => isAdmin ? handleAdminLogout() : setAdminModalOpen(true)}
              data-tooltip={isAdmin ? 'Logout Admin' : 'Admin Login'}
              style={{ color: isAdmin ? '#ff3b3b' : undefined, borderColor: isAdmin ? 'rgba(255,59,59,0.6)' : undefined }}
            >
              {isAdmin ? '🔓' : '🔒'}
            </button>
            <button className="nav-icon-btn" type="button" onClick={handleThemeToggle} data-tooltip="Tema">
              {theme === 'dark' ? '🌙' : '☀️'}
            </button>
          </div>
          <button
            className={`music-btn ${musicPlaying ? 'playing' : ''}`}
            type="button"
            onClick={toggleMusic}
            data-tooltip={musicPlaying ? 'Matikan Musik' : 'Nyalakan Musik'}
            aria-label="Toggle musik"
          >
            <span className="music-bars" aria-hidden="true">
              <span/><span/><span/><span/>
            </span>
          </button>
          <a className="btn btn-primary" href="https://chat.whatsapp.com/BbLtlR1EbviEHDnaUSvGYz" target="_blank" rel="noreferrer">
            GABUNG
          </a>
        </div>
      </header>

      <main>
        <section className="hero section" id="beranda">
          <div className="section-bg-text">KYOKO</div>
          <div className="hero-content fade-section">
            <div className="tagline">WhatsApp Bot · Official</div>
            <h1>
              KYOKO <span>/</span> MD
            </h1>
            <p className="subtitle">By Ryuuki Kojo · Powered for the Community</p>
            <p className="description">
              Bot WhatsApp multifungsi dengan fitur lengkap. Gabung komunitas dan rasakan pengalaman chat yang lebih seru!
            </p>
            <div className="hero-actions">
              <a className="btn btn-primary" href="https://chat.whatsapp.com/BbLtlR1EbviEHDnaUSvGYz" target="_blank" rel="noreferrer">
                Official Group
              </a>
              <a className="btn btn-secondary" href="https://whatsapp.com/channel/0029Vb5avimI1rcisKNii32A" target="_blank" rel="noreferrer">
                Official Channel
              </a>
            </div>
            <div className="visitor-counter">
              <span className="visitor-icon">👥</span>
              <span className="visitor-number">{visitorCount}</span>
              <span className="visitor-label">Pengunjung</span>
            </div>
          </div>
        </section>

        <div className="ticker" aria-hidden="true">
          <div className="ticker-track">
            <span>KYOKOMD · COMMUNITY READY · MULTI COMMAND · PLUGIN SYSTEM · ALWAYS ONLINE · </span>
            <span>KYOKOMD · COMMUNITY READY · MULTI COMMAND · PLUGIN SYSTEM · ALWAYS ONLINE · </span>
          </div>
        </div>

        <div className="film-divider" aria-hidden="true" />

        <section className="section fade-section" id="info-berita">
          <div className="section-number">02</div>
          <div className="section-bg-text">LINKS</div>
          <div className="section-header">
            <h2>Official Links</h2>
            <p>Selalu terhubung dengan jalur resmi KyokoMd.</p>
          </div>
          <div className="card-grid">
            <a className="link-card" href="https://chat.whatsapp.com/BbLtlR1EbviEHDnaUSvGYz" target="_blank" rel="noreferrer">
              <div className="card-title">Official Group WhatsApp</div>
              <div className="card-desc">Highlight utama untuk bergabung dan berdiskusi.</div>
            </a>
            <a className="link-card" href="https://whatsapp.com/channel/0029Vb5avimI1rcisKNii32A" target="_blank" rel="noreferrer">
              <div className="card-title">Official Channel WhatsApp</div>
              <div className="card-desc">Update terbaru dan info fitur bot.</div>
            </a>
            <a className="link-card" href="https://t.me/kyokomd" target="_blank" rel="noreferrer">
              <div className="card-title">Telegram Hub</div>
              <div className="card-desc">Komunitas tambahan untuk diskusi dan support.</div>
            </a>
          </div>
        </section>

        <div className="film-divider reverse" aria-hidden="true" />

        <section className="section fade-section" id="karakter">
          <div className="section-number">03</div>
          <div className="section-bg-text">SOCIAL</div>
          <div className="section-header">
            <h2>Sosial Media</h2>
            <p>Ikuti semua kanal konten resmi dan aktivitas komunitas.</p>
          </div>
          <div className="card-grid">
            <a className="link-card" href="https://youtube.com/@ryuukikojo" target="_blank" rel="noreferrer">
              <div className="card-title">YouTube</div>
              <div className="card-desc">Video showcase dan tutorial fitur bot.</div>
            </a>
            <a className="link-card" href="https://www.instagram.com/yusha_desuwa" target="_blank" rel="noreferrer">
              <div className="card-title">Instagram</div>
              <div className="card-desc">Konten visual terbaru dan highlight komunitas.</div>
            </a>
            <a className="link-card" href="https://www.facebook.com/share/1BFS6ndTdF/" target="_blank" rel="noreferrer">
              <div className="card-title">Facebook</div>
              <div className="card-desc">Berita dan pengumuman resmi.</div>
            </a>
          </div>
        </section>

        <section className="diagonal-band">
          <div className="band-text">JOIN THE SIGNAL · POWERED FOR THE COMMUNITY · KYOKOMD READY</div>
        </section>

        <section className="section fade-section" id="latar-belakang">
          <div className="section-number">04</div>
          <div className="section-bg-text">FEATURES</div>
          <div className="section-header">
            <h2>Fitur Utama</h2>
            <p>Arsitektur bot modern dengan fokus pada fleksibilitas dan komunitas.</p>
          </div>
          <div className="feature-list">
            <div className="feature-item">Multi-Command untuk berbagai kebutuhan chat.</div>
            <div className="feature-item">Plugin System modular dan mudah diperluas.</div>
            <div className="feature-item">Aktif & Diperbarui secara berkala.</div>
            <div className="feature-item">Komunitas aktif untuk dukungan dan sharing.</div>
          </div>
        </section>

        <div className="film-divider" aria-hidden="true" />

        <section className="section fade-section" id="direktori-grup">
          <div className="section-number">05</div>
          <div className="section-bg-text">GROUPS</div>
          <div className="section-header">
            <h2>Direktori Grup</h2>
            <p>Temukan grup komunitas sesuai minat. Tambahkan grup milikmu untuk terhubung dengan lebih banyak teman.</p>
          </div>
          <div className="group-actions">
            <button
              className="btn btn-primary"
              onClick={() => {
                setGroupForm((prev) => ({ ...prev, category: activeCategory }))
                setIsModalOpen(true)
              }}
            >
              Tambah Grup
            </button>
            <div className="group-nav">
              <button className="group-nav-btn" onClick={() => handleGroupNav('left')} aria-label="Sebelumnya">
                ←
              </button>
              <button className="group-nav-btn" onClick={() => handleGroupNav('right')} aria-label="Berikutnya">
                →
              </button>
            </div>
          </div>
          <div className="group-search">
            <input
              type="search"
              placeholder="Cari grup berdasarkan nama atau kategori..."
              value={groupSearch}
              onChange={(event) => setGroupSearch(event.target.value)}
            />
          </div>
          {groupSearch.trim() ? (
            <div className="group-results">
              {filteredGroups.length ? (
                filteredGroups.map((group, index) => (
                  <a className="group-card" key={`${group.name}-${index}`} href={group.link} target="_blank" rel="noreferrer">
                    <div className="card-title">{group.name}</div>
                    <div className="card-desc">{group.desc}</div>
                    <div className="group-tag">{group.category}</div>
                    <div className={`group-expire ${getDaysLeft(group.createdAt) <= 7 ? 'warn' : ''}`}>
                      Kedaluwarsa dalam {getDaysLeft(group.createdAt)} hari
                    </div>
                    <button
                      className="group-renew"
                      type="button"
                      onClick={(event) => {
                        event.preventDefault()
                        handleRenewGroup(group.link)
                      }}
                    >
                      Perbarui
                    </button>
                  </a>
                ))
              ) : (
                <div className="group-empty">Grup tidak ditemukan</div>
              )}
            </div>
          ) : (
            <div className={`group-carousel ${groupSlideDirection}`}>
              <div className="group-category">
                <div className="group-title active">{activeCategory}</div>
                <div className="group-list">
                  {visibleGroups.length ? (
                    visibleGroups.map((group, index) => (
                      <a className="group-card" key={`${group.name}-${index}`} href={group.link} target="_blank" rel="noreferrer">
                        <div className="card-title">{group.name}</div>
                        <div className="card-desc">{group.desc}</div>
                        <div className={`group-expire ${getDaysLeft(group.createdAt) <= 7 ? 'warn' : ''}`}>
                          Kedaluwarsa dalam {getDaysLeft(group.createdAt)} hari
                        </div>
                        <button
                          className="group-renew"
                          type="button"
                          onClick={(event) => {
                            event.preventDefault()
                            handleRenewGroup(group.link)
                          }}
                        >
                          Perbarui
                        </button>
                      </a>
                    ))
                  ) : (
                    <div className="group-empty">Belum ada grup di kategori ini.</div>
                  )}
                </div>
                {groups[activeCategory]?.length > 5 && !expandedCategories[activeCategory] && (
                  <button
                    className="group-more"
                    onClick={() => setExpandedCategories((prev) => ({ ...prev, [activeCategory]: true }))}
                  >
                    Lihat Semua
                  </button>
                )}
              </div>
            </div>
          )}
          <div className="group-indicator">
            {activeCategory.toUpperCase()} ({activeGroupIndex + 1}/{groupCategories.length})
          </div>
        </section>

        <section className="section fade-section" id="rekomendasi-game">
          <div className="section-number">06</div>
          <div className="section-bg-text">GAMES</div>
          <div className="section-header">
            <h2>Rekomendasi Game</h2>
            <p>Pilihan game favorit komunitas. Pilih genre dan langsung menuju Play Store.</p>
          </div>
          <div className="genre-tabs">
            {(['RPG', 'MOBA', 'FPS'] as const).map((genre) => (
              <button key={genre} className={`genre-btn ${activeGenre === genre ? 'active' : ''}`} onClick={() => setActiveGenre(genre)}>
                {genre}
              </button>
            ))}
          </div>
          <div className="card-grid">
            {gameData[activeGenre].map((game) => (
              <div className="game-card" key={game.name}>
                <div className="card-title">{game.name}</div>
                <a className="btn btn-secondary" href={game.link} target="_blank" rel="noreferrer">
                  Download
                </a>
              </div>
            ))}
          </div>
        </section>

        <div className="film-divider" aria-hidden="true" />

        <section className="section fade-section" id="berita-game">
          <div className="section-number">08</div>
          <div className="section-bg-text">NEWS</div>
          <div className="section-header">
            <h2>BERITA GAME</h2>
            <p className="section-tag">Update Terbaru</p>
            <p>Berita dan update terbaru seputar game favoritmu</p>
          </div>
          <div className="news-actions">
            <div className="news-filters">
              {['Semua', 'Genshin', 'Mobile Legends', 'Free Fire', 'Wuthering Waves'].map((filter) => (
                <button
                  key={filter}
                  className={`news-filter ${newsFilter === filter ? 'active' : ''}`}
                  onClick={() => setNewsFilter(filter)}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className="news-track">
            {filteredNews.length === 0 && <div className="news-empty">Berita tidak tersedia saat ini. Coba lagi nanti.</div>}
            {filteredNews.length > 0 && (
              <div className="news-scroll">
                {filteredNews.map((item, index) => (
                  <article key={`${item.title}-${index}`} className="news-card" style={{ animationDelay: `${0.1 * index}s` }}>
                    <div className="news-thumb">
                      {typeof item.image === 'string' && item.image.startsWith('http') ? (
                        <img
                          src={item.image}
                          alt={item.title}
                          onError={(event) => {
                            const target = event.currentTarget
                            target.style.display = 'none'
                            const parent = target.parentElement
                            if (parent && !parent.querySelector('.news-placeholder')) {
                              const placeholder = document.createElement('div')
                              placeholder.className = 'news-placeholder'
                              const span = document.createElement('span')
                              span.textContent = gameEmoji[item.game] || gameEmoji.default
                              placeholder.appendChild(span)
                              parent.appendChild(placeholder)
                            }
                          }}
                        />
                      ) : (
                        <div className="news-placeholder">
                          <span>{gameEmoji[item.game] || gameEmoji.default}</span>
                        </div>
                      )}
                    </div>
                    <div className="news-source">{item.source}</div>
                    <div className="news-title">{item.title}</div>
                    <div className="news-desc">
                      {(item.description || '').slice(0, 60)}{(item.description || '').length > 60 ? '...' : ''}
                    </div>
                    <div className="news-footer">
                      <span className="news-date">{formatDate(item.date)}</span>
                      <a className="btn btn-secondary" href={item.url} target="_blank" rel="noreferrer">
                        Baca
                      </a>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>

        <section className="section fade-section" id="apk-mod">
          <div className="section-number">09</div>
          <div className="section-bg-text">APKMOD</div>
          <div className="section-header">
            <h2>APK Mod & ScBot</h2>
            <p>Kumpulan APK dan ScBot pilihan dari KyokoMd.</p>
          </div>
          {isAdmin && (
            <div className="apk-admin-bar">
              <button className="btn btn-primary" onClick={() => setUploadModal('apk')}>+ Upload APK</button>
              <button className="btn btn-primary" onClick={() => setUploadModal('free')}>+ Upload ScBot Free</button>
              <button className="btn btn-primary" onClick={() => setUploadModal('premium')}>+ Upload ScBot Premium</button>
            </div>
          )}
          {/* ── Tab buttons + search slide-out ─────────────────────── */}
          <div className="apk-tabs-wrap">
            {/* APK MOD tab */}
            <div className="apk-tab-group">
              <button
                className={`apk-tab-btn ${apkTab === 'apk' ? 'active' : ''}`}
                onClick={() => { setApkTab('apk'); setApkSearchOpen(false); setFreeSearchOpen(false); setPremiumSearchOpen(false) }}
              >🎮 APK MOD</button>
              {apkTab === 'apk' && (
                <button className="apk-search-icon-btn" onClick={() => setApkSearchOpen(p => !p)} type="button" title="Cari APK">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </button>
              )}
              {apkTab === 'apk' && apkSearchOpen && (
                <input
                  className="apk-search-input"
                  type="text"
                  placeholder="Cari APK..."
                  value={apkSearch}
                  onChange={e => setApkSearch(e.target.value)}
                  autoFocus
                />
              )}
            </div>
            {/* SCBOT FREE tab */}
            <div className="apk-tab-group">
              <button
                className={`apk-tab-btn ${apkTab === 'free' ? 'active' : ''}`}
                onClick={() => { setApkTab('free'); setApkSearchOpen(false); setFreeSearchOpen(false); setPremiumSearchOpen(false) }}
              >🤖 SCBOT FREE</button>
              {apkTab === 'free' && (
                <button className="apk-search-icon-btn" onClick={() => setFreeSearchOpen(p => !p)} type="button" title="Cari ScBot Free">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </button>
              )}
              {apkTab === 'free' && freeSearchOpen && (
                <input
                  className="apk-search-input"
                  type="text"
                  placeholder="Cari ScBot Free..."
                  value={freeSearch}
                  onChange={e => setFreeSearch(e.target.value)}
                  autoFocus
                />
              )}
            </div>
            {/* SCBOT PREMIUM tab */}
            <div className="apk-tab-group">
              <button
                className={`apk-tab-btn ${apkTab === 'premium' ? 'active' : ''}`}
                onClick={() => { setApkTab('premium'); setApkSearchOpen(false); setFreeSearchOpen(false); setPremiumSearchOpen(false) }}
              >⭐ SCBOT PREMIUM</button>
              {apkTab === 'premium' && (
                <button className="apk-search-icon-btn" onClick={() => setPremiumSearchOpen(p => !p)} type="button" title="Cari ScBot Premium">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </button>
              )}
              {apkTab === 'premium' && premiumSearchOpen && (
                <input
                  className="apk-search-input"
                  type="text"
                  placeholder="Cari ScBot Premium..."
                  value={premiumSearch}
                  onChange={e => setPremiumSearch(e.target.value)}
                  autoFocus
                />
              )}
            </div>
          </div>

          {/* ── Category chips ─────────────────────────────────── */}
          {apkTab === 'apk' && (
            <div className="apk-cat-chips">
              {['Semua', ...apkCategories].map(cat => (
                <button key={cat} className={`apk-cat-chip ${apkCategory === cat ? 'active' : ''}`} onClick={() => setApkCategory(cat)} type="button">
                  {cat === 'Game' ? '🎮' : cat === 'Sosmed' ? '📱' : cat === 'AI' ? '🤖' : cat === 'Lainnya' ? '📦' : '✨'} {cat}
                </button>
              ))}
            </div>
          )}


          {/* ── APK List ───────────────────────────────────────── */}
          {apkTab === 'apk' && (() => {
            const q = apkSearch.toLowerCase()
            const shown = apkList.filter(item =>
              (apkCategory === 'Semua' || (item as any).category === apkCategory) &&
              (!q || item.name.toLowerCase().includes(q) || item.desc?.toLowerCase().includes(q))
            )
            return (
              <div className="apk-list">
                {shown.length === 0 && <div className="group-empty">Belum ada APK tersedia saat ini.</div>}
                {shown.map((item, i) => (
                  <div className="apk-card" key={item.id}>
                    {isAdmin && (
                      <div className="apk-dots-wrap">
                        <button className="apk-dots" onClick={() => setMenuDots(menuDots === `apk-${i}` ? null : `apk-${i}`)}>⋮</button>
                        {menuDots === `apk-${i}` && (
                          <div className="apk-dots-menu"><button onClick={() => handleDelete('apk', apkList.indexOf(item))}>🗑 Hapus</button></div>
                        )}
                      </div>
                    )}
                    {(item as any).category && <div className="apk-cat-badge">{(item as any).category === 'Game' ? '🎮' : (item as any).category === 'Sosmed' ? '📱' : (item as any).category === 'AI' ? '🤖' : '📦'} {(item as any).category}</div>}
                    <div className="apk-name">{item.name}</div>
                    {item.version && <div className="apk-version">v{item.version}</div>}
                    {item.desc && <div className="apk-desc">{item.desc}</div>}
                    <a className="btn btn-primary" href={item.link} target="_blank" rel="noreferrer">DOWNLOAD</a>
                  </div>
                ))}
              </div>
            )
          })()}

          {/* ── ScBot Free List ────────────────────────────────── */}
          {apkTab === 'free' && (() => {
            const q = freeSearch.toLowerCase()
            const shown = scbotFreeList.filter(item =>
              (!q || item.name.toLowerCase().includes(q) || item.desc?.toLowerCase().includes(q))
            )
            return (
              <div className="apk-list">
                {shown.length === 0 && <div className="group-empty">Belum ada ScBot Free tersedia saat ini.</div>}
                {shown.map((item, i) => (
                  <div className="apk-card" key={item.id}>
                    {isAdmin && (
                      <div className="apk-dots-wrap">
                        <button className="apk-dots" onClick={() => setMenuDots(menuDots === `free-${i}` ? null : `free-${i}`)}>⋮</button>
                        {menuDots === `free-${i}` && (
                          <div className="apk-dots-menu"><button onClick={() => handleDelete('free', scbotFreeList.indexOf(item))}>🗑 Hapus</button></div>
                        )}
                      </div>
                    )}
                    {(item as any).category && <div className="apk-cat-badge">{(item as any).category === 'Game' ? '🎮' : (item as any).category === 'Utility' ? '🔧' : (item as any).category === 'Fun' ? '🎉' : '📦'} {(item as any).category}</div>}
                    <div className="apk-name">{item.name}</div>
                    {item.version && <div className="apk-version">v{item.version}</div>}
                    {item.desc && <div className="apk-desc">{item.desc}</div>}
                    <a className="btn btn-primary" href={item.link} target="_blank" rel="noreferrer">DOWNLOAD</a>
                  </div>
                ))}
              </div>
            )
          })()}

          {/* ── ScBot Premium List ─────────────────────────────── */}
          {apkTab === 'premium' && (() => {
            const q = premiumSearch.toLowerCase()
            const shown = scbotPremiumList.filter(item =>
              (!q || item.name.toLowerCase().includes(q) || item.desc?.toLowerCase().includes(q))
            )
            return (
              <div className="apk-list">
                {shown.length === 0 && <div className="group-empty">Belum ada ScBot Premium tersedia saat ini.</div>}
                {shown.map((item, i) => (
                  <div className="apk-card" key={item.id}>
                    {isAdmin && (
                      <div className="apk-dots-wrap">
                        <button className="apk-dots" onClick={() => setMenuDots(menuDots === `prem-${i}` ? null : `prem-${i}`)}>⋮</button>
                        {menuDots === `prem-${i}` && (
                          <div className="apk-dots-menu"><button onClick={() => handleDelete('premium', scbotPremiumList.indexOf(item))}>🗑 Hapus</button></div>
                        )}
                      </div>
                    )}
                    {(item as any).category && <div className="apk-cat-badge">{(item as any).category === 'Game' ? '🎮' : (item as any).category === 'Utility' ? '🔧' : (item as any).category === 'Fun' ? '🎉' : '📦'} {(item as any).category}</div>}
                    <div className="apk-name">{item.name}</div>
                    {item.version && <div className="apk-version">v{item.version}</div>}
                    {item.desc && <div className="apk-desc">{item.desc}</div>}
                    {(item as any).price && <div className="apk-price">💰 {(item as any).price}</div>}
                    <div className="apk-btns">
                      {item.waLink && (
                        <a className="btn apk-buy-btn" href={item.waLink} target="_blank" rel="noreferrer">💬 BELI VIA WA</a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )
          })()}
        </section>

        <section className="section fade-section" id="kirim-masukan">
          <div className="section-number">10</div>
          <div className="section-bg-text">RATING</div>
          <div className="section-header">
            <h2>Rating & Ulasan</h2>
            <p>Berikan rating dan ulasanmu untuk KyokoMd. Bantu kami berkembang lebih baik!</p>
          </div>

          {/* Rating summary */}
          {ratings.length > 0 && (
            <div className="rating-summary">
              <div className="rating-avg">
                {(ratings.reduce((s, r) => s + r.star, 0) / ratings.length).toFixed(1)}
              </div>
              <div className="rating-summary-right">
                <div className="rating-stars-display">
                  {[1,2,3,4,5].map(s => (
                    <span key={s} className={s <= Math.round(ratings.reduce((acc, r) => acc + r.star, 0) / ratings.length) ? 'star-filled' : 'star-empty'}>★</span>
                  ))}
                </div>
                <div className="rating-count">{ratings.length} ulasan</div>
                {/* Bar chart per bintang */}
                <div className="rating-bars">
                  {[5,4,3,2,1].map(s => {
                    const count = ratings.filter(r => r.star === s).length
                    const pct = ratings.length ? (count / ratings.length) * 100 : 0
                    return (
                      <div className="rating-bar-row" key={s}>
                        <span>{s}★</span>
                        <div className="rating-bar-track"><div className="rating-bar-fill" style={{width: `${pct}%`}} /></div>
                        <span>{count}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Form beri rating */}
          <div className="rating-form-wrap">
            <h3 className="rating-form-title">Tulis Ulasan</h3>
            <div className="rating-star-input">
              {[1,2,3,4,5].map(s => (
                <button
                  key={s}
                  className={`star-btn ${s <= (ratingHover || ratingForm.star) ? 'star-active' : ''}`}
                  onMouseEnter={() => setRatingHover(s)}
                  onMouseLeave={() => setRatingHover(0)}
                  onClick={() => setRatingForm(p => ({...p, star: s}))}
                  type="button"
                >★</button>
              ))}
            </div>
            <input
              className="rating-input"
              type="text"
              placeholder="Nama kamu"
              value={ratingForm.name}
              onChange={e => setRatingForm(p => ({...p, name: e.target.value}))}
            />
            <textarea
              className="rating-input"
              placeholder="Tulis ulasanmu (opsional)"
              value={ratingForm.comment}
              onChange={e => setRatingForm(p => ({...p, comment: e.target.value}))}
              rows={3}
            />
            <button className="btn btn-primary" onClick={handleRatingSubmit} type="button">
              Kirim Ulasan
            </button>
            {ratingStatus === 'success' && <p className="form-status success">Ulasan berhasil dikirim! Terima kasih.</p>}
          </div>

          {/* List ulasan — 3 teratas + tombol filter kategori */}
          {(() => {
            const filtered = ratingFilter ? ratings.filter(r => r.star === ratingFilter) : ratings
            const shown = filtered.slice(0, ratingShowCount)
            const hasMore = filtered.length > ratingShowCount
            const totalHidden = ratings.length - 3
            const showFilterBtn = ratings.length > 3
            return (
              <>
                <div className="rating-list">
                  {shown.length === 0 && (
                    <div className="group-empty">Belum ada ulasan bintang {ratingFilter} saat ini.</div>
                  )}
                  {shown.map((r) => (
                    <div className="rating-card" key={r.id}>
                      {isAdmin && (
                        <button className="rating-delete-btn" onClick={() => handleDeleteRating(r.id)} title="Hapus">✕</button>
                      )}
                      <div className="rating-card-top">
                        <span className="rating-card-name">{r.name}</span>
                        <span className="rating-card-stars">
                          {[1,2,3,4,5].map(s => <span key={s} className={s <= r.star ? 'star-filled' : 'star-empty'}>★</span>)}
                        </span>
                      </div>
                      {r.comment && <p className="rating-card-comment">{r.comment}</p>}
                    </div>
                  ))}
                </div>

                {/* Tombol load more + filter bubble */}
                <div className="rating-more-wrap">
                  <div className="rating-more-row">
                    {hasMore && (
                      <button
                        className="rating-more-btn rating-load-more"
                        onClick={() => setRatingShowCount(c => c + 3)}
                        type="button"
                      >
                        + Lihat {Math.min(filtered.length - ratingShowCount, 3)} ulasan lagi
                      </button>
                    )}
                    {showFilterBtn && (
                      <button
                        className="rating-more-btn"
                        onClick={() => setRatingBubbleOpen(p => !p)}
                        type="button"
                      >
                        {ratingFilter ? `Filter: Bintang ${ratingFilter} ★` : `Filter ★`}
                        <span className={`rating-more-arrow ${ratingBubbleOpen ? 'open' : ''}`}>▾</span>
                      </button>
                    )}
                    {ratingBubbleOpen && (
                      <div className="rating-bubble">
                        <button className={`rb-item ${!ratingFilter ? 'rb-active' : ''}`} onClick={() => { setRatingFilter(null); setRatingShowCount(3); setRatingBubbleOpen(false) }} type="button">Semua ★</button>
                        {[5,4,3,2,1].map(s => (
                          <button key={s} className={`rb-item ${ratingFilter === s ? 'rb-active' : ''}`} onClick={() => { setRatingFilter(s); setRatingShowCount(3); setRatingBubbleOpen(false) }} type="button">{s} ★ ({ratings.filter(r => r.star === s).length})</button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </>
            )
          })()}
        </section>
      </main>

      <footer className="footer">
        <div className="footer-logo">
          <span className="logo-mark">K</span>
          <div>
            <div className="logo-title">KyokoMd</div>
            <div className="logo-sub">WhatsApp Bot · Official</div>
          </div>
        </div>
        <div className="socials">
          <a
            href="https://saweria.co/YukiDesu/toko-top-up"
            target="_blank"
            rel="noreferrer"
            aria-label="Top-Up Shop"
            data-tooltip="Top-Up Shop"
          >
            🛒
          </a>
          <a href="https://youtube.com/@ryuukikojo" target="_blank" rel="noreferrer" aria-label="YouTube">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M21.6 7.2a2.7 2.7 0 0 0-1.9-1.9C17.9 5 12 5 12 5s-5.9 0-7.7.3A2.7 2.7 0 0 0 2.4 7.2C2 9 2 12 2 12s0 3 0.4 4.8a2.7 2.7 0 0 0 1.9 1.9C6.1 19 12 19 12 19s5.9 0 7.7-0.3a2.7 2.7 0 0 0 1.9-1.9C22 15 22 12 22 12s0-3-0.4-4.8ZM10 15V9l5 3-5 3Z" />
            </svg>
          </a>
          <a href="https://www.instagram.com/yusha_desuwa" target="_blank" rel="noreferrer" aria-label="Instagram">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M7 3h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4Zm10 2H7a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2Zm-5 3.5a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11Zm0 2a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Zm5.2-3.4a1.3 1.3 0 1 1 0 2.6 1.3 1.3 0 0 1 0-2.6Z" />
            </svg>
          </a>
          <a href="https://www.facebook.com/share/1BFS6ndTdF/" target="_blank" rel="noreferrer" aria-label="Facebook">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M13.5 9H16V6h-2.5C11 6 10 7.5 10 9.4V11H8v3h2v7h3v-7h2.4l.6-3H13V9.8c0-.5.2-.8.9-.8Z" />
            </svg>
          </a>
          <a href="https://t.me/kyokomd" target="_blank" rel="noreferrer" aria-label="Telegram">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M20.9 4.6c.5-.2.9.3.7.8l-3 13.7c-.1.5-.7.7-1.1.4l-4.2-3.1-2 1.9c-.2.2-.6.1-.6-.2l.1-3.4 7.7-7.1c.3-.3-.1-.7-.5-.4l-9.4 5.8-3.7-1.2c-.5-.2-.5-.9 0-1.1l15.9-6.1Z" />
            </svg>
          </a>
        </div>
        <p className="copyright">© 2024 KyokoMd. Powered for the Community.</p>
      </footer>

      <button className="chat-fab" onClick={() => setChatOpen((prev) => !prev)} aria-label="Buka KyokoAI">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M4 4h16v10H7l-3 3V4Zm4 4h8v2H8V8Zm0 4h5v2H8v-2Z" />
        </svg>
      </button>

      <div className={`chat-widget ${chatOpen ? 'open' : ''}`}>
        <div className="chat-header">
          <div>
            <div className="chat-title">KyokoAI</div>
            <div className="chat-sub">Powered by Anthropic</div>
          </div>
          <button className="chat-close" onClick={() => setChatOpen(false)}>
            ×
          </button>
        </div>
        <div className="chat-body">
          {chatMessages.map((message, index) => (
            <div key={`${message.role}-${index}`} className={`chat-bubble ${message.role}`}>
              {message.content}
            </div>
          ))}
          {chatLoading && (
            <div className="typing-indicator">
              <span></span>
              <span></span>
              <span></span>
            </div>
          )}
        </div>
        <div className="chat-input">
          <input
            type="text"
            value={chatInput}
            onChange={(event) => setChatInput(event.target.value)}
            placeholder="Tulis pesan..."
            onKeyDown={(event) => {
              if (event.key === 'Enter') {
                handleChatSend()
              }
            }}
          />
          <button className="btn btn-primary" onClick={handleChatSend} disabled={chatLoading}>
            Kirim
          </button>
        </div>
      </div>

      {isModalOpen && (
        <div className="modal-overlay" onClick={() => setIsModalOpen(false)}>
          <div className="modal" onClick={(event) => event.stopPropagation()}>
            <div className="modal-header">
              <div>
                <div className="modal-title">Tambah Grup</div>
                <div className="modal-sub">Masukkan detail grup WhatsApp kamu.</div>
              </div>
              <button className="chat-close" onClick={() => setIsModalOpen(false)}>
                ×
              </button>
            </div>
            <form className="modal-form" onSubmit={handleGroupSubmit}>
              <label>
                <span>Nama Grup</span>
                <input
                  type="text"
                  value={groupForm.name}
                  onChange={(event) => setGroupForm((prev) => ({ ...prev, name: event.target.value }))}
                  required
                />
              </label>
              <label>
                <span>Link WhatsApp</span>
                <input
                  type="url"
                  value={groupForm.link}
                  onChange={(event) => {
                    setGroupForm((prev) => ({ ...prev, link: event.target.value }))
                    setGroupErrors((prev) => ({ ...prev, link: '' }))
                  }}
                  required
                />
                {groupErrors.link && <span className="input-error">{groupErrors.link}</span>}
              </label>
              <label>
                <span>Kategori</span>
                <select
                  value={groupForm.category}
                  onChange={(event) => setGroupForm((prev) => ({ ...prev, category: event.target.value }))}
                >
                  {groupCategories.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </select>
              </label>
              <label>
                <span>Deskripsi Singkat</span>
                <textarea
                  value={groupForm.desc}
                  onChange={(event) => setGroupForm((prev) => ({ ...prev, desc: event.target.value }))}
                  required
                />
              </label>
              <div className="form-actions">
                <button className="btn btn-primary" type="submit">
                  Simpan
                </button>
                <button className="btn btn-secondary" type="button" onClick={() => setIsModalOpen(false)}>
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {adminModalOpen && (
        <div className="modal-overlay" onClick={() => setAdminModalOpen(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <div className="modal-title">ADMIN LOGIN</div>
                <div className="modal-sub">Masukkan kredensial admin.</div>
              </div>
              <button className="chat-close" onClick={() => setAdminModalOpen(false)}>×</button>
            </div>
            <div className="modal-form">
              <label><span>Username</span>
                <input type="text" placeholder="Username" value={adminUser} onChange={e => setAdminUser(e.target.value)} />
              </label>
              <label><span>Kode Akses</span>
                <input type="password" placeholder="8 digit kode" value={adminCode} onChange={e => setAdminCode(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleAdminLogin()} />
              </label>
              {adminError && <div className="input-error">{adminError}</div>}
              <div className="form-actions">
                <button className="btn btn-primary" onClick={handleAdminLogin}>LOGIN</button>
                <button className="btn btn-secondary" onClick={() => setAdminModalOpen(false)}>Batal</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {uploadModal && (
        <div className="modal-overlay" onClick={() => setUploadModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <div className="modal-title">
                  {uploadModal === 'apk' ? 'UPLOAD APK' : uploadModal === 'free' ? 'UPLOAD SCBOT FREE' : 'UPLOAD SCBOT PREMIUM'}
                </div>
                <div className="modal-sub">Isi detail file yang akan diupload.</div>
              </div>
              <button className="chat-close" onClick={() => setUploadModal(null)}>×</button>
            </div>
            <div className="modal-form">
              <label><span>Nama</span>
                <input type="text" value={uploadForm.name} onChange={e => setUploadForm(p => ({...p, name: e.target.value}))} required />
              </label>
              <label><span>Kategori</span>
                <select value={uploadForm.category} onChange={e => setUploadForm(p => ({...p, category: e.target.value}))}>
                  {uploadModal === 'apk'
                    ? ['Game','Sosmed','AI','Lainnya'].map(c => <option key={c}>{c}</option>)
                    : ['Game','Utility','Fun','Lainnya'].map(c => <option key={c}>{c}</option>)
                  }
                </select>
              </label>
              {uploadModal !== 'premium' && (
                <label><span>Link Download</span>
                  <input type="url" value={uploadForm.link} onChange={e => setUploadForm(p => ({...p, link: e.target.value}))} required />
                </label>
              )}
              {uploadModal === 'premium' && (
                <label><span>Harga / Price</span>
                  <input type="text" placeholder="Contoh: Rp 15.000" value={uploadForm.link} onChange={e => setUploadForm(p => ({...p, link: e.target.value}))} required />
                </label>
              )}
              <label><span>Versi (opsional)</span>
                <input type="text" value={uploadForm.version} onChange={e => setUploadForm(p => ({...p, version: e.target.value}))} />
              </label>
              <label><span>Deskripsi (opsional)</span>
                <textarea value={uploadForm.desc} onChange={e => setUploadForm(p => ({...p, desc: e.target.value}))} />
              </label>
              {uploadModal === 'premium' && (
                <label><span>Link WA Pembelian</span>
                  <input type="url" placeholder="https://wa.me/..." value={uploadForm.waLink} onChange={e => setUploadForm(p => ({...p, waLink: e.target.value}))} />
                </label>
              )}
              <div className="form-actions">
                <button className="btn btn-primary" onClick={handleUpload}>UPLOAD</button>
                <button className="btn btn-secondary" onClick={() => setUploadModal(null)}>Batal</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <button
        className={`scroll-top ${showScrollTop ? 'visible' : ''}`}
        type="button"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        aria-label="Scroll ke atas"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="18 15 12 9 6 15"/>
        </svg>
        <span className="scroll-top-label">ATAS</span>
      </button>
      <div className={`menu-overlay ${menuOpen ? 'open' : ''}`} onClick={() => setMenuOpen(false)}>
        <div className="menu-panel" onClick={(event) => event.stopPropagation()}>
          <div className="menu-header">
            <div className="menu-logo">KyokoMd</div>
            <button className="menu-close" type="button" onClick={() => setMenuOpen(false)} aria-label="Tutup menu">
              ×
            </button>
          </div>
          <nav className="menu-items">
            {[
              { label: 'Beranda', id: 'beranda' },
              { label: 'Karakter', id: 'karakter' },
              { label: 'Info & Berita', id: 'info-berita' },
              { label: 'Latar Belakang', id: 'latar-belakang' },
              { label: 'Direktori Grup', id: 'direktori-grup' },
              { label: 'Rekomendasi Game', id: 'rekomendasi-game' },
              { label: 'Rating', id: 'kirim-masukan' },
            ].map((item, index) => (
              <button
                key={item.id}
                type="button"
                className="menu-item"
                style={{ transitionDelay: `${0.08 * index}s` }}
                onClick={() => handleMenuClick(item.id)}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <a className="menu-cta" href="https://chat.whatsapp.com/BbLtlR1EbviEHDnaUSvGYz" target="_blank" rel="noreferrer">
            GABUNG
          </a>
        </div>
      </div>
    </div>
    </>
  )
}

export default App
